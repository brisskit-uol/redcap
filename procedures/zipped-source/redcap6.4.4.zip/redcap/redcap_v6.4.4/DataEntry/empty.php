<?php
//This is an empty file used for IE6 compatibility when dealing with iframes.

// Turn off error reporting
error_reporting(0);
// Make sure the character set is UTF-8
ini_set('default_charset', 'UTF-8');