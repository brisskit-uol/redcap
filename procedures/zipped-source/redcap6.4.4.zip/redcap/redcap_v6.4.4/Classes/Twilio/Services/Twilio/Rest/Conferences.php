<?php

class Services_Twilio_Rest_Conferences
    extends Services_Twilio_ListResource
{
}
